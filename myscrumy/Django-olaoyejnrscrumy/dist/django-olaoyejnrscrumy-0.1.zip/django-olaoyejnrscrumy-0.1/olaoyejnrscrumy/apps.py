from django.apps import AppConfig


class OlaoyejnrscrumyConfig(AppConfig):
    name = 'olaoyejnrscrumy'
